const productsElem = document.querySelector('.products');
const itemsElem = document.querySelector('.items');
const btnElem = document.querySelector('.addtocart');

const baseUrl = 'http://localhost:8000/api/products/';
const cartUrl = 'http://localhost:8000/api/cart/';

let data = [];
let cart = [];

// Function to get data
async function getData() {
    const response = await fetch(baseUrl);
    data = await response.json();
    //console.log(data);
    displayData();
    //console.log('get data');
}

// Function to get 
async function getCart() {
    const response = await fetch(cartUrl);
    cart = await response.json();
    //console.log(cart);
    productsInCart.innerHTML = cart.length;
}

//function to display the data of the page
function displayData() {
    productsElem.innerHTML = '';
    //console.log('data function');
    if (data.length > 0) {
    for (let i = 0; i < data.length; i++) {
        let node = document.createElement('li');
        let images = document.createElement('img');
        let addButton = document.createElement('button');
        node.innerHTML = data[i].name + ' - ' + data[i].price;
        const imagesUrl = 'http://localhost:8000' + data[i].img;
        images.setAttribute('src', imagesUrl);
        addButton.setAttribute('data-code', data[i].id);
        addButton.innerHTML = 'Add to cart';
        node.append(addButton);
        productsElem.append(node);
        node.appendChild(images);
        //console.log(images);
        addButton.addEventListener('click', (event) => {
            const code = event.target.getAttribute('data-code');
            addButton.innerHTML = 'In cart'
            addToCart(code);
        })
    }
    } else {
        let node = document.createElement('li');
        node.innerHTML = 'No items in cart. Buy a spaceship. NOW.';
        productsElem.append(node);
    }
}

// Function to add an item to the cart
async function addToCart (code){
    const newCartUrl = cartUrl + '?id=' + code;
    //console.log(newCartUrl);
    const response = await fetch(newCartUrl, {method: 'POST'});
    const answer = await response.json();
    //console.log(answer);
    displayCart();
    //console.log('look for ' + code);
    getCart();
}

// Function to display the cart
function displayCart() {
    if (data.length > 0) {
        for (let i = 0; i < data.length; i++) {
        let node = document.createElement('li');
        node.innerHTML = data[i].Name + ' - ' + data[i].Price;
    }
    } else {
        let node = document.createElement('li');
        node.innerHTML = 'cart function';
    }
}
getData();

