const cartUrl = 'http://localhost:8000/api/cart/';
const productsElem = document.querySelector('.cart-container');

let cart = [];

// Function to get the cart
async function getCart() {
    const response = await fetch(cartUrl);
    cart = await response.json();
    //console.log(cart);
    productsInCart.innerHTML = cart.length;
    displayDataInCart();
}
getCart();

// Function to display data in the cart
function displayDataInCart() {
    productsElem.innerHTML = '';
    //console.log('data function');
    if (cart.length > 0) {
    for (let i = 0; i < cart.length; i++) {
        let node = document.createElement('li'); // Creates a 'li' tag inside cart
        let images = document.createElement('img'); // Creates the images inside cart
        let deleteButton = document.createElement('button'); // Creates the delete button inside cart
        node.innerHTML = cart[i].name + ' - ' + cart[i].price;
        const imagesUrl = 'http://localhost:8000' + cart[i].img;
        images.setAttribute('src', imagesUrl);
        deleteButton.setAttribute('data-code', cart[i].id);
        deleteButton.innerHTML = 'delete';
        node.append(deleteButton);
        productsElem.append(node);
        node.appendChild(images);
        //console.log(images);
        deleteButton.addEventListener('click', (event) => {
            const code = event.target.getAttribute('data-code');
            deleteFromCart(code);
        })
    }
    } else {
        let node = document.createElement('li');
        node.innerHTML = 'No items in cart. Buy a spaceship. NOW.';
        productsElem.append(node);
    }
}

// Function to delete from cart
async function deleteFromCart (node) {
    const newCartUrl = cartUrl + '?id=' + node;
    //console.log(newCartUrl);
    const response = await fetch(newCartUrl, {method: 'DELETE'});
    const answer = await response.json();
    //console.log(answer);
    displayDataInCart();
    //console.log('look for ' + code);
    getCart();
}

